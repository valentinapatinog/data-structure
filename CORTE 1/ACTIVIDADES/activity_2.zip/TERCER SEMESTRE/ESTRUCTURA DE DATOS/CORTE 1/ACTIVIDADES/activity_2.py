'''
activity 2
'''

#Nombre de la clase 
class Activity2:

#Metodo inicializador
    def _init_(self):
        
#Variables globales de la clase
        self.user_document = 0
        
